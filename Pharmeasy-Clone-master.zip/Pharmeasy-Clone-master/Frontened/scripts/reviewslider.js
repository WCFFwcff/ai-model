function reviewslider() {


    return `<div class="carousel001" data-flickity='{ "wrapAround": true }'>
        <div class="carousel-cell001">
            <div class="reviewbox">
                <h3>Debanjan Roy</h3>
                <p>April 18, 2020</p>
                <div class="dtreview">
                    <h2>"</h2>
                    Very good app. Whould recomended to everyone requring fast and efficient delivery of medical product
                    at the
                    doorstep.
                </div>
            </div>
        </div>
        <div class="carousel-cell001">
            <div class="reviewbox">
                <h3>Rohini Sarkar</h3>
                <p>April 21, 2020</p>
                <div class="dtreview">
                    <h2>"</h2>Very helpful and friendly app interms of usability, customer supprot and money saving from
                    point of
                    medical necessity of everyperson.
                </div>
            </div>
        </div>
        <div class="carousel-cell001">
            <div class="reviewbox">
                <h3>Rajarshi Sarkar</h3>
                <p>April 22, 2020</p>
                <div class="dtreview">
                    <h2>"</h2>The app is really very wonderfull. Being a product manager myself. I would say that the
                    user
                    expericence(UI/UX) of this app is top notch(easy to use, simple and convinient)
                </div>
            </div>
        </div>
        <div class="carousel-cell001">
            <div class="reviewbox">
                <h3>Darpan Dholkiya</h3>
                <p>April 23, 2020</p>
                <div class="dtreview">
                    <h2>"</h2>Best service and app amongst all available. I have been using for than 3 years and even
                    during the
                    pandemic, they have keep their standerds high and are delivering the order within 24hours.
                </div>
            </div>
        </div>
        <div class="carousel-cell001">
            <div class="reviewbox">
                <h3>Lipi Choudhary</h3>
                <p>April 15, 2020</p>
                <div class="dtreview">
                    <h2>"</h2>this app is game changer for me. I am unable to go out and bue medical product. Pharmesy
                    gives me the
                    last liberty to shop essiential healthcare product from home
                </div>
            </div>
        </div>
        <div class="carousel-cell001">
            <div class="reviewbox">
                <h3>Thrithankar Das</h3>
                <p>April 23, 2020</p>
                <div class="dtreview">
                    <h2>"</h2>Very good app and Very helpful and friendly app interms of usability, customer supprot and
                    money
                    saving from point of medical necessity for everyperson.
                </div>
            </div>
        </div>
        <div class="carousel-cell001">
            <div class="reviewbox">
                <h3>Varun Sonagra</h3>
                <p>April 23, 2020</p>
                <div class="dtreview">
                    <h2>"</h2>I have a good expericence. The Condition with the doctor feature works well too. The price
                    and
                    discount are also great too. Overall the simplicity of the app is a plus too. I recommended this
                    app.
                </div>
            </div>
        </div>
    </div>`


}

export default reviewslider;