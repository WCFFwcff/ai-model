function healthslider(){

    return ` <div class="carousel" data-flickity='{ "wrapAround": true }'>

        <div class="carousel-cell">
           <img src=" https://cms-contents.pharmeasy.in/banner/711032a7dc9-Ostocalcium.jpg?dim=700x0&dpr=1&q=100" alt=""></div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F516ecec4bb9-Iodex-CB-Feb-22.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F40e236d7036-Cremaffin-SB-18.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F834dd1e570e-HorlicksJunior-Native-Jan22.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2Fa342fb7a234-AG-SRP-Feb.png&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F23f9dc691a0-Otrivin-CB.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F9bbb51f0753-Dipya-CB-Feb22.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
            <img src="https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F166210223f3-Soulflower-InsideCB-Oct21.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
            <img src="https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F60b1a9b7f03-Mamaexpert_C_B.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2F40e4bb39ec9-Nicotex-CB.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
            <img src="https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2Fa27116b60ca-2baconil_CB.jpg&w=750&q=75" alt="">
        </div>
        <div class="carousel-cell">
           <img src=" https://pharmeasy.in/_next/image?url=https%3A%2F%2Fcms-contents.pharmeasy.in%2Fbanner%2Fa9f03ee8c8d-Godrej-CB-feb.jpg&w=750&q=75" alt="">
        </div>
    </div>`


}

export default healthslider;